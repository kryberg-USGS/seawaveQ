#' An R package for the U.S. Geological Survey seawaveQ model, a 
#' parametric regression model specifically designed for analyzing 
#' seasonal- and flow-related variability and trends in pesticide 
#' concentrations.  See Vecchia and others (2008) for the original 
#' description of the model and see Sullivan and others (2009), 
#' Vecchia and others (2009), Ryberg and others (2010), 
#' Ryberg and others (2014), Ryberg and Gilliom (2015), 
#' and Oelsner and others (2017) and for applications of 
#' the model.
#'
#' \tabular{ll}{
#' Package: \tab seawaveQ\cr
#' Type: \tab Package\cr
#' Version: \tab 2.0.1\cr
#' Date: \tab 2020--07--29\cr
#' License: \tab Unlimited | file LICENSE \cr
#' }
#'
#' @name seawaveQ-package
#' @aliases seawaveQ
#' @docType package
#' @title A model and utilities for analyzing trends in chemical 
#' concentrations in streams with a seasonal wave (seawave) and 
#' adjustment for streamflow (Q) and other ancillary variables 
#' (Q) and other ancillary variables
#' @author Karen R. Ryberg \email{kryberg@@usgs.gov} and 
#' Aldo V. Vecchia \email{avecchia@@usgs.gov}
#' @keywords package
#' @references 
#'
#' Oelsner, G.P., Sprague, L.A., Murphy, J.C., Zuellig, R.E., Johnson, H.M., 
#' Ryberg, K.R., Falcone, J.A., Stets, E.G., Vecchia, A.V., Riskin, M.L., 
#' De Cicco, L.A., Mills, T.J., and Farmer, W.H., 2017, Water-quality trends 
#' in the nation's rivers and streams, 1972--2012---Data preparation, statistical 
#' methods, and trend results: U. S. Geological Survey Scientific Investigations 
#' Report 2017--5006, 136 p., \url{https://doi.org/10.3133/sir20175006}.
#'
#' Ryberg, K.R. and Gilliom, R.J., 2015, Trends in pesticide concentrations 
#' and use for major rivers of the United States: Science of The Total Environment, 
#' v. 538, p. 431--444,  \url{https://doi.org/10.1016/j.scitotenv.2015.06.095}.
#'
#' Ryberg, K.R. and Vecchia, A.V., 2013, seawaveQ---An R package providing 
#' a model and utilities for analyzing trends in chemical concentrations 
#' in streams with a seasonal wave (seawave) and adjustment for 
#' streamflow (Q) and other ancillary variables: U.S. Geological Survey 
#' Open-File Report 2013--1255, 13 p., with 3 appendixes, 
#' \url{https://dx.doi.org/10.3133/ofr20131255}.
#' 
#' Ryberg, K.R. and York, B.C., 2020, seawaveQ---An R package providing 
#' a model and utilities for analyzing trends in chemical concentrations 
#' in streams with a seasonal wave (seawave) and adjustment for 
#' streamflow (Q) and other ancillary variables, Version 2.0.0: U.S. Geological 
#' Survey Open-File Report 2020--1082, 25 p., with 4 appendixes.
#' 
#' Ryberg, K.R., Vecchia, A.V., Gilliom, R.J., and Martin, J.D., 2014, 
#' Pesticide trends in major rivers of the United States, 1992--2010: 
#' U.S. Geological Survey Scientific Investigations Report 2014--5135, 
#' 74 p., \url{https://pubs.er.usgs.gov/publication/sir20145135}.
#'
#' Ryberg, K.R., Vecchia, A.V., Martin, J.D., Gilliom, R.J., 2010, Trends 
#' in pesticide concentrations in urban streams in the United States, 
#' 1992--2008: U.S. Geological Survey Scientific Investigations Report 
#' 2010--5139, 101 p., \url{https://pubs.usgs.gov/sir/2010/5139/}.
#'
#' Sullivan, D.J., Vecchia, A.V., Lorenz, D.L., Gilliom, R.J., Martin, 
#' J.D., 2009, Trends in pesticide concentrations in corn-belt streams, 
#' 1996--2006: U.S. Geological Survey Scientific Investigations Report 
#' 2009--5132, 75 p., \url{https://pubs.usgs.gov/sir/2009/5132/}.
#' 
#' Vecchia, A.V., Gilliom, R.J., Sullivan, D.J., Lorenz, D.L., and 
#' Martin, J.D., 2009, Trends in concentrations and use of agricultural 
#' herbicides for Corn Belt rivers, 1996--2006: Environmental Science 
#' and Technology, v. 43, no. 24, p. 9096--9102.
#'
#' Vecchia, A.V., Martin, J.D., and Gilliom, R.J., 2008, Modeling 
#' variability and  trends in pesticide concentrations in streams: 
#' Journal of the American Water Resources Association, v. 44, no. 5, p. 
#' 1308--1324, \url{https://dx.doi.org/10.1111/j.1752-1688.2008.00225.x}.
NULL
